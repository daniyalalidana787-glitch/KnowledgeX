# KnowledgeX — Phase 1 frontend prototype

A responsive, single-page educational website prototype.

## Run locally
1. Unzip the project.
2. Open `index.html` in a modern browser.

No build tools are required for this frontend preview.

## Included
- Responsive KnowledgeX landing page
- Pakistan and international examination category cards
- Interactive 5-question sample quiz with explanations
- Demo dashboard with browser-local progress
- Demo login/registration interface

## Important limitations
This is a frontend prototype, not a production-connected application.
- Login and registration are demo-only and stored in the current browser's localStorage.
- Google sign-in button is a setup placeholder; it does not authenticate.
- No real Supabase database is connected.
- Quiz data is sample content.
- No real email is sent.
- No admin system or production security is implemented.

## Next production steps
1. Create a Supabase project.
2. Configure Supabase Auth (email and Google OAuth).
3. Add database schema and Row Level Security policies.
4. Replace demo authentication with Supabase Auth.
5. Move answer-key grading to a secure server-side function.
6. Add verified question-bank content and an admin workflow.
7. Deploy via Lovable hosting or Vercel.

Do not collect real user passwords with the demo form.
